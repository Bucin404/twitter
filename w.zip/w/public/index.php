<?php
declare(strict_types = 1);

if (session_status() !== PHP_SESSION_ACTIVE) {
  session_start();
}

use DI\ContainerBuilder;
use Slim\Factory\AppFactory;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Log\LoggerInterface;

require __DIR__ . '/../vendor/autoload.php';

// Instantiate PHP-DI ContainerBuilder
$containerBuilder = new ContainerBuilder();

if (false) {
  // Should be set to true in production
  $containerBuilder->enableCompilation(__DIR__ . '/../var/cache');
}

// Set up settings
$settings = require __DIR__ . '/../app/settings.php';
$settings($containerBuilder);

// Set up dependencies
$dependencies = require __DIR__ . '/../app/dependencies.php';
$dependencies($containerBuilder);

// key management
$key_m = require __DIR__ . '/../app/key/main.php';
$key_m($containerBuilder);

// Build PHP-DI Container instance
$container = $containerBuilder->build();

// Instantiate the app
AppFactory::setContainer($container);

$app = AppFactory::create();
$callableResolver = $app->getCallableResolver();

// Register middleware
$middleware = require __DIR__ . '/../app/middleware.php';
$middleware($app);

// Register routes
$routes = require __DIR__ . '/../app/routes.php';
$routes($app);


/**@var SettingsInterface $settings */
$settings = $container->get('settings');

$displayErrorDetails = $settings['displayErrorDetails'];
$logError = $settings['logError'];
$logErrorDetails = $settings['logErrorDetails'];

$errHandler = function (
  ServerRequestInterface $request,
  Throwable $exception,
  bool $displayErrorDetails,
  bool $logErrors,
  bool $logErrorDetails,
  ?LoggerInterface $logger = null
) use ($app, $container) {
  $msg = $exception->getMessage();
  $response = $app->getResponseFactory()->createResponse();
  if($request->isPost())
    $response = $response->withJson([
      'msg' => $msg,
      'success' => false
    ], 500);
  else
    $response
      ->getBody()
      ->write($msg);
  return $response;
};

$errorMiddleware = $app->addErrorMiddleware($displayErrorDetails, $logError, $logErrorDetails);
if(!$displayErrorDetails)
  $errorMiddleware->setDefaultErrorHandler($errHandler);

$app->run();
