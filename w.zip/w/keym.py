from requests import Session
from urllib.parse import urljoin
from time import time
from random import choice, randint
from hashlib import md5
from os import system, get_terminal_size as ts
from string import ascii_lowercase

import readline

s = Session()
s.headers.update({
  'X-Password': 'TEST'
})

if input('local(Y/N)?: ').lower()[0]=='y':
  BASE_URL = 'http://localhost:8080'
else:
  BASE_URL = 'https://kbl-tool.000webhostapp.com/'

rstr = lambda : md5((str(time())+str.join('',[choice(list(ascii_lowercase)) for x in range(randint(30,35))])).encode()).hexdigest()
produks = s.get(urljoin(BASE_URL, 'admin-key/produk')).json()
def show_produk():
  print('\x1b[5m'+('[List Produk]'.center(ts().columns))+'\x1b[0m\n')
  for n, v in enumerate(produks):
    print('[%d]\n' % (n + 1))
    print(' nama          : ',v['nama'])
    print(' route         : ',v['route'])
    print(' harga         : ',v['harga'])
    print(' limit(default): ',v['limit'])
    print()
  else:
    print('[empty]')

def main():
  system('clear')
  pilih = input('\n [web]: \x1b[5m\x1b[4m%s\x1b[0m\n\n\n[0] Keluar\n[1] Lihat daftar key\n[2] Tambah key\n[3] Delete key\n[4] Get trial\n[5] Get limit\n\n[?] pilih nomor: ' % BASE_URL)
  if pilih.isdigit():
    print()
    pilih = int(pilih)
    if pilih == 0:
      exit('[Exit]')
    elif pilih == 1:
      print('\x1b[5m'+('[Data]'.center(ts().columns))+'\x1b[0m\n')
      data=s.get(urljoin(BASE_URL, '/admin-key/list'))
      if data.text:
        for n, d in enumerate(data.json()):
          print('[%d]\n' % (n + 1))
          print(' nama          : ',d['nama'])
          print(' key           : ',d['keyo'])
          print(' key(remember) : ',d['keyr'])
          print(' limit(default): ',d['limit'])
          print()
        else:
          print('[empty]')
    elif pilih == 2:
      show_produk()
      print('\n\x1b[5m'+('[Tambah Key]'.center(ts().columns))+'\x1b[0m\n')
      keyr = rstr()
      key = input('[?] key(blank for random): ')
      limit = input('[?] limit(number): ')
      produk = int(input('[?] pilih produk(number): '))
      if len(key) < 8:
        key = rstr()
      if not limit.isdigit():
        limit = ''
      nama = produks[produk-1]['route']
      Y = input('\n[?] tambah(Y/N): ')
      if 'y' == Y.lower():
        print('\n\x1b[5m'+('[Result]'.center(ts().columns))+'\x1b[0m\n')
        print('\n[+] key          : ', key, '\n[+] key(remember): ', keyr)
        print('[*] message: ', s.post(urljoin(BASE_URL, 'admin-key/add'), data={'keyr': keyr, 'limit' : limit, 'key': key, 'name': nama}).text)
    elif pilih == 3:
      print('\x1b[5m'+('[Delete Key]'.center(ts().columns))+'\x1b[0m\n')
      key = input('[key|key(r)]: ')
      print('[msg]: ', s.post(urljoin(BASE_URL, 'admin-key/delete'), data={'key': key}).text)
    elif pilih == 4:
      show_produk()
      print('\n\x1b[5m'+('[Trial Key]'.center(ts().columns))+'\x1b[0m\n')
      produk = int(input('[?] pilih produk(number): '))
      key = 'TRIAL'+str(randint(1000,9999))
      nama = produks[produk-1]['route']
      print('[+] key: ', key,'\n[+] produk: ', nama)
      print('[msg]: ',s.post(
        urljoin(BASE_URL, 'admin-key/add'), data = {
          'limit': '1',
          'key': key,
          'keyr': key,
          'name': nama
      }).text)
    elif pilih == 5:
      print('\n\x1b[5m'+('[Get Limit]'.center(ts().columns))+'\x1b[0m\n')
      key = input('[?] key: ')
      if key:
        limit = s.get(urljoin(BASE_URL, 'admin-key/limit/%s' % key)).text
        if limit != '0':
          print('[+] limit: ', limit)
        else:
          print('[+] msg: Key NotFound...')
      else:
        print('[empty]')
  input('\n\n[Enter] ')
  main()

try:
  main()
except Exception as e:
  print('[msgErr]: ', e)
