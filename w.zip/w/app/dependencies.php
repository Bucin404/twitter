<?php
declare(strict_types = 1);

use DI\ContainerBuilder;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use Monolog\Processor\UidProcessor;
use Psr\Container\ContainerInterface;
use Psr\Log\LoggerInterface;
use Slim\Views\Twig;
use Slim\Views\TwigMiddleware;
use Slim\Flash\Messages;
use Slim\Csrf\Guard;
use Slim\Psr7\Factory\ResponseFactory;
use Twig\TwigFunction;
use Slim\Psr7\Response as Responsex;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

return function (ContainerBuilder $containerBuilder) {
  $containerBuilder->addDefinitions([
    'admin-acc' => function (ContainerInterface $c) {
      $pwaccess = $c->get('settings')['keyManagement']['password'];
      return function($req, $handler) use ($pwaccess) {
        if ($req->getHeaderLine('X-Password') === $pwaccess)
          return $handler->handle($req);
        return new Responsex();
      };
    },

    'db' => function (ContainerInterface $c) {
      $dbset = $c->get('settings')['dbset'];
      $pdo = new PDO("mysql:host=${dbset['host']};dbname=${dbset['name']}", $dbset['user'], $dbset['pass']);
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
      $pdo->exec("
        CREATE TABLE IF NOT EXISTS `keys`(
          `keyo` TEXT NOT NULL,
          `keyr` TEXT NOT NULL,
          `nama` TEXT NOT NULL,
          `limit` INTEGER NOT NULL DEFAULT 0
        );
      ");
      $pdo->exec("
        CREATE TABLE IF NOT EXISTS `trialkey`(
          `is_used` INTEGER(1) NOT NULL DEFAULT 0,
          `key` TEXT NOT NULL,
          `expired` TEXT NOT NULL
        );
      ");
      $pdo->exec("
        CREATE TABLE IF NOT EXISTS `lastkey`(
          `key` TEXT NOT NULL,
          `ua` TEXT NOT NULL
        )
      ");
      return $pdo;
    },

    'chapta' => function (ContainerInterface $c) {
      $chapta = $c->get('settings')['chapta'];
      return function($req, $handler) use ($chapta) {
        if ($req->isPost()) {
          $data = $req->getParsedBody();
          $res = new Responsex();
          if (array_key_exists($chapta['value_name'], $data)) {
            $chaptas = $data[$chapta['value_name']];
            $secret = $chapta['secretkey'];
            $chaptav = json_decode(file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$chaptas"), TRUE);
            if (!$chaptav['success']) {
              $res
              ->getBody()
              ->write(json_encode(array('msg' => $chaptav['error-codes'])));
              return $res->withStatus(500);
            }
          } else {
            $res
            ->getBody()
            ->write(json_encode(array('msg' => 'chapta invalid')));
            return $res->withStatus(500);
          }
        }
        return $handler->handle($req);
      };
    },
    'csrf' => function (ContainerInterface $c) {
      $responseFactory = new ResponseFactory();
      $guard = new Guard($responseFactory);
      $guard->setPersistentTokenMode(true);
      $guard->setFailureHandler(function ($request, $handler) {
        $res = new Responsex();
        $res
          ->getBody()
          ->write(json_encode([
            'msg' => 'invalid token'
        ]));
        return $res->withStatus(500);
      });

      return $guard;
    },

    'flash' => function (ContainerInterface $c) {
      $storage = [];
      return new Messages($storage);
    },

    'view' => function (ContainerInterface $c) {
      $settings = $c->get('settings');

      $twgSetting = $settings['twig'];
      $twig = Twig::create($twgSetting['template_path'], [
        'cache' => false,
        'debug' => false,
        'reload' => true
      ]);

      $envt = $twig->getEnvironment();
      $envt->addGlobal('settings', $settings);
      $envt->addGlobal('produks', array_values($c->get('produks')));
      $envt->addFunction(new TwigFunction('flash', function($key) use ($c) {
        return $c->get('flash')->getFirstMessage($key);
      }));
      $envt->addFunction(new TwigFunction('cookies', function ($key) {
        if (isset($_COOKIE[$key]))
          return $_COOKIE[$key];
        return '';
      }));

      $envt->addFunction(new TwigFunction('csrf_token',
        function ($js = false) use ($c) {
          $token = $c->get('csrf')->generateToken();
          $csrf_name = $token['csrf_name'];
          $csrf_value = $token['csrf_value'];
          return $js
          ? json_encode($token)
          : "<input type='hidden' name='csrf_name' value='$csrf_name'>" . PHP_EOL .
          "<input type='hidden' name='csrf_value' value='$csrf_value'>";
        }));

      return $twig;
    },

    'logger' => function (ContainerInterface $c) {
      $settings = $c->get('settings');

      $loggerSettings = $settings['logger'];
      $logger = new Logger($loggerSettings['name']);

      $processor = new UidProcessor();
      $logger->pushProcessor($processor);

      $handler = new StreamHandler($loggerSettings['path'],
        $loggerSettings['level']);
      $logger->pushHandler($handler);

      return $logger;
    }
  ]);
};
