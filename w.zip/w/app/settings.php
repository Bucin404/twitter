<?php
declare(strict_types = 1);

use DI\ContainerBuilder;
use Monolog\Logger;

return function (ContainerBuilder $containerBuilder) {
  $is_prod = getenv('ENV') === 'prod';
  // Global Settings Object
  $containerBuilder->addDefinitions([
    'settings' => [
      'logo' => [
        'android' => '/img/logo.png',
        'desktop' => '/img/logo.png',
        'profile' => '/img/asecx.jpg'
      ],
      'title' => [
         'title' => 'AseCx',
      ],
      'adminContact' => [
         'wa' => '6289510512322'
       ],
      'keyManagement' => [
        'password' => 'TEST' // ganti nanti
      ],
      'chapta' => [
        'sitekey' => '',
        'secretkey' => '',
        'value_name' => ''
      ],
      'is_prod' => $is_prod,
      'displayErrorDetails' => $is_prod,
      'logError' => false,
      'logErrorDetails' => false,
      'twig' => [
        'template_path' => __DIR__ . '/../templates/',
      ],
      // database
      'dbset' => $is_prod ? [
        'user' => 'root',
        'pass' => '1234',
        'name' => 'asex',
        'host' => 'localhost'
      ] : [
        'user' => 'root',
        'pass' => '1234',
        'name' => 'asex',
        'host' => 'localhost'
      ],
      'logger' => [
        'name' => 'slim-app',
        'path' => 'php://stdout',
        'level' => Logger::DEBUG,
      ]
    ]
  ]);
};
