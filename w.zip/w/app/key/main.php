<?php
declare(strict_types = 1);

use DI\ContainerBuilder;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use Monolog\Processor\UidProcessor;
use Psr\Container\ContainerInterface;
use Psr\Log\LoggerInterface;
use Slim\Views\Twig;
use Slim\Views\TwigMiddleware;
use Slim\Flash\Messages;
use Slim\Csrf\Guard;
use Slim\Psr7\Factory\ResponseFactory;
use Twig\TwigFunction;
use Slim\Psr7\Response as Responsex;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface;

return function ($containerBuilder) {
  $containerBuilder->addDefinitions([
    'produks' => [
      'test-key' => [
        'nama' => 'Test key',
        'route' => 'test-key',
        'harga' => '0',
        'limit' => '0'
      ]
    ],
    'have-key' => function ($c) {
      $db = $c->get('db');
      return function ($req, $handler) use ($db) {
        $route_path = $req
          ->getUri()
          ->getPath();
        $route_name = \Slim\Routing\RouteContext::fromRequest($req)
          ->getRoute()
          ->getName();
        $nres = new Responsex();
        $res = $handler->handle($req);
        if (array_key_exists($route_name, $this->get('produks'))) {
          if (isset($_COOKIE['tm']))
            setcookie('tm', (string)(((int)$_COOKIE['tm']) + 1), (time() + 3600 * 1), $route_path);
          if ($req->isPost()) {
            $key = $_COOKIE['key'];
            if ($key) {
              $sth = $db->prepare("
                  SELECT `is_used` FROM `trialkey` WHERE `key` = :key
                ");
              $sth->execute([
                "key" => $key
              ]);
              $data = $sth->fetch();
              if ($data) {
                if ($data['is_used'] === '0') {
                  $db->prepare("
                      UPDATE `trialkey`
                      SET `is_used` = 1
                      WHERE `key` = :key
                    ")->execute([
                    'key' => $key
                  ]);
                  return $res;
                } else {
                  return $nres->withJson([
                    'msg' => 'trialkey arleady used and only have one remaining',
                    'fromkey' => 'true'
                  ], 500);
                }
              } else {
                $sth = $db->prepare("
                    SELECT `limit`, `nama` FROM `keys` WHERE `keyo` = :key OR `keyr` = :key
                ");
                $sth->execute([
                  "key" => $key
                ]);
                $data = $sth->fetch();
                if ($data) {
                  if ($data['limit'] > 1) {
                    $db->prepare("
                      UPDATE `keys` SET `limit` = :limit WHERE `keyo` = :key OR `keyr` = :key
                    ")
                    ->execute([
                      "key" => $key,
                      "limit" => (int)$data['limit'] - 1
                    ]);
                    $sth = $db->prepare("
                      SELECT * FROM `keys`
                      WHERE `keyo` = :key
                    ");
                    $sth->execute([
                      'key' => $key
                    ]);
                    if (!isset($_COOKIE['keyr']) && $sth->fetch()) {
                      $sth = $db->prepare("
                        SELECT * FROM `lastkey`
                        WHERE `key` = :key AND `ua` = :ua
                      ");
                      $sth->execute([
                        'key' => $key,
                        'ua' => $_SERVER['HTTP_USER_AGENT']
                      ]);
                      if (!$sth->fetch()) {
                        $db->prepare("
                          INSERT INTO `lastkey`(
                            `key`, `ua`
                          ) VALUES(?, ?)
                        ")->execute([$key, $_SERVER['HTTP_USER_AGENT']]);
                      } else {
                        $sth->prepare("
                          DELETE FROM `lastkey`
                          WHERE `key` = :key AND `ua` = :ua
                        ")->execute([
                          'key' => $key,
                          'ua' => $_SERVER['HTTP_USER_AGENT']
                        ]);
                        return $nres->withJson([
                          'fromkey' => true,
                          'msg' => 'your key is not premium, you have to enter it again, the browser will restart immediately.'
                        ], 500);
                      }
                    }

                  } else {
                    $db->prepare("
                      DELETE FROM `keys` WHERE `keyo` = :key OR `keyr` = :key
                    ")
                    ->execute(["key" => $key]);
                  }
                  return $res;
                }
              }
              return $nres->withJson(['msg' => 'your key is not available, it may have reached the usage time limit.', 'fromkey' => true], 500);
            } else {
              return $nres->withJson(['msg' => 'require key for accesing this', 'fromkey' => true], 500);
            }
          } elseif ($req->isGet()) {
            setcookie('is_produk', 'true', (time() + 3600), $route_path);
            if (isset($_COOKIE['key'])) {
              $sth = $db->prepare ("
                  SELECT * FROM `trialkey` WHERE `key` = :key
                ");
              $sth->execute(["key" => $_COOKIE['key']]);
              $data = $sth->fetch();
              if ($data) {
                if ($data['is_used'] !== '0') {
                  unset($_COOKIE['is_used']);
                  unset($_COOKIE['trialkey']);
                  unset($_COOKIE['key']);

                  setcookie('is_used', '1', time() - 3600, $route_path);
                  setcookie('trialkey', 'true', time() - 3600, $route_path);
                  setcookie('key', '', time() - 3600, $route_path);
                }
              } else {
                $sth = $db->prepare ("
                      SELECT `limit` FROM `keys` WHERE `keyo` = :key OR `keyr` = :key
                    ");
                $sth->execute(["key" => $_COOKIE['key']]);
                $data = $sth->fetch();
                if (!$data) {
                  unset($_COOKIE['key']);
                  unset($_COOKIE['tm']);
                  unset($_COOKIE['limit']);
                  setcookie('key', '', time() - 3600, $route_path);
                  setcookie('keyr', '', time() - 3600, $route_path);
                  setcookie('tm', '2', time() - 3600, $route_path);
                  setcookie('limit', '', time() - 3600, $route_path);

                } else {
                  setcookie('limit', $data['limit'], (time() + 3600), $route_path);
                }
                if (!isset($_COOKIE['keyr']) && isset($_COOKIE['tm']) && ((int)$_COOKIE['tm']) >= 1) {
                  unset($_COOKIE['key']);
                  unset($_COOKIE['tm']);
                  unset($_COOKIE['limit']);

                  setcookie('key', '', time() - 3600, $route_path);
                  setcookie('tm', '0', time() - 3600, $route_path);
                  setcookie('limit', '', time() - 3600, $route_path);
                }
              }
            }
          }
        }
        return $res;
      };
    }
  ]);
};
