<?php
use Slim\App;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Slim\Interfaces\RouteCollectorProxyInterface as Group;

return function(App $app){

  $container = $app->getContainer();
  $db = $container->get('db');

  $app->group('/admin-key', function ($key) use ($db) {
    $key->get('/limit/{key}', function ($req, $res, $args) use ($db) {
      $limit = '0';
      $key = $args['key'];
      $sth = $db->prepare("
        SELECT `limit`
        FROM `keys`
        WHERE `keyo` = :key OR `keyr` = :key
      ");
      $sth->execute([
        'key' => $key
      ]);
      $data = $sth->fetch();
      if ($data) $limit = $data['limit'];
      $res->getBody()->write($limit);
      return $res;
    })->setName('get-limit-key');

    $key->get('/produk',
      function (Request $req, Response $res) {
        return $res->withJson(array_values($this->get('produks')));
      })->add('admin-acc');

    $key->post('/check',
      function(Request $req, Response $res) use($db) {
        $data = $req->getParsedBody();
        $redirect = $data && $data['next'] ? $data['next'] : '/';
        if ($data && array_key_exists('key', $data)) {
          $key = $data['key'];
          $sth = $db->prepare("
            SELECT `is_used` FROM `trialkey` WHERE `key` = :key
          ");
          $sth->execute([
            'key' => $key
          ]);
          $data = $sth->fetch();
          if ($data) {
            if ($data['is_used'] === '0') {
              $r = '/';
              $rr = explode(explode($req->getUri()->getPath(), (string)$req->getUri())[0], $redirect);
              if (empty($rr[0]) && count($rr) === 2)
                $r = $rr[1];
              setcookie('trialkey', 'true', time() + 3600 * 1, $r);
              setcookie('is_used', '0', time() + 3600 * 1, $r);
              setcookie('key', $key, time() + 3600 * 1, $r);
              if (isset($_COOKIE['keyr']) && isset($_COOKIE['limit'])) {
                unset($_COOKIE['keyr']);
                unset($_COOKIE['limit']);
                setcookie('keyr', '', time() - 3600, $r);
                setcookie('limit', '', (time() - 3600), $r);
              }
            } else {
              $this->get('flash')->addMessage('cekkey', 'This key can only be used once, the key you entered may already be used by someone else');
            }
          } else {
            $sth = $db->prepare("
            SELECT * FROM `keys` WHERE `keyr` = :key OR `keyo` = :key
          ");
            $sth->execute([
              'key' => $key
            ]);
            $data = $sth->fetch();
            if ($data) {
              $route_path = \Slim\Routing\RouteContext::fromRequest($req)
              ->getRouteParser()
              ->urlFor($data['nama']);
              setcookie('tm', '0', (time() + 3600 * 24), $route_path);
              if ($data["keyr"] === $key) {
                if (isset($_COOKIES['trailkey']) && isset($_COOKIES['is_used'])) {
                  unset($_COOKIE['trialkey']);
                  unset($_COOKIE['is_used']);
                  setcookie('trialkey', '', time() - 3600, $route_path);
                  setcookie('is_used', '', time() - 3600, $route_path);
                }
                setcookie('keyr', 'true', (time() + 3600 * 24 * 365), $route_path);
                setcookie('key', $key, (time() + 3600 * 24 * 365), $route_path);
                setcookie('limit', $data['limit'], (time() + 3600), $route_path);

              } elseif ($data["keyo"] === $key) {
                setcookie('key', $key, (time() + 3600 * 1), $route_path);
              }
            } else {
              $this->get('flash')->addMessage('cekkey', 'the key you entered is not valid');
            }
          }
          return $res->withRedirect($redirect);
        }
      })
    ->setName('cek-key')
    ->add('csrf');

    $key->get('/list',
      function(Request $req, Response $res) use($db) {
        $sth = $db->prepare("
            SELECT * FROM `keys`
          ");
        $sth->execute();
        return $res->withJson($sth->fetchAll());

      })->add('admin-acc');

    $key->post('/delete',
      function (Request $req, Response $res) use($db) {
        $data = $req->getParsedBody();
        if ($data && array_key_exists('key', $data)) {
          $sth = $db->prepare("
            DELETE FROM `keys` WHERE `keyo` = :key OR `keyr` = :key
          ");
          $sth->execute([
            'key' => $data['key']
          ]);
          return $res->withJson([
            'msg' => 'success'
          ]);
        }
      })->add('admin-acc');

    $key->post('/add',
      function(Request $req, Response $res) use($db) {
        $data = $req->getParsedBody();
        $keyr = $data['keyr'];
        $key = $data['key'];
        $name = $data['name'];
        $limit = $data['limit'];
        if (array_key_exists($name, $this->get('produks'))) {
          $sth = $db->prepare("
            SELECT * FROM `keys` WHERE `keyo` = :key
            ");
          $sth->execute([
            'key' => $key
          ]);
          if (!$sth->fetch()) {
            $sth = $db->prepare("
            INSERT INTO `keys`(
              `keyo`,
              `keyr`,
              `nama`,
              `limit`
            ) VALUES(?,?,?,?)
            ");

            $sth->execute([$key, $keyr, $name, $limit ? $limit : $this->get('produks')[$name]['limit']]);
            return $res->withJson([
              'msg' => 'success',
              'success' => true
            ]);
          } else {
            return $res->withJson([
              'msg' => 'key ini sudah ada',
              'success' => false
            ]);
          }
        } else {
          return $res->withJson([
            'msg' => "route name '${name}' tidak ada dalam list",
            'success' => false
          ]);
        }
      })->add('admin-acc');

    $key->get('/buy',
      function(Request $req, Response $res) use($db) {
        $db->exec("
          DELETE
          FROM `trialkey`
          WHERE
            unix_timestamp(expired) < unix_timestamp(now())
        ");
        $sth = $db->prepare("
          SELECT `key`, `is_used`
          FROM `trialkey`
        ");
        $sth->execute();
        $data = $sth->fetch();
        if (!$data) {
          $trial_key = 'TRIAL'.md5((string)time());
          $db->prepare("
            INSERT INTO `trialkey`(
              `key`,
              `expired`
            )
            VALUES(?, ?)
          ")->execute([
            $trial_key,
            date('c', time() + ($this->get('settings')['trialkey'][1] * 24 * 60 * 60))
          ]);
          $data = ['key' => $trial_key,
            'is_used' => '0'];
        }
        return $this->get('view')->render($res,
          'pages/buy-key.html',
          ['data' => $data]);
      })->setName('buy-key');
  });
};
