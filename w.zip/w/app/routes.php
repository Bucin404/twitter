<?php
declare(strict_types = 1);

use Slim\App;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Slim\Interfaces\RouteCollectorProxyInterface as Group;

return function (App $app) {

  // set key
  $key_management = require __DIR__ . "/key/route.php";
  $key_management($app);


  // auto create image metacontent by maoundis
  $app->get('/image/{title}', function (Request $req, Response $res, $args) {
    ob_start();
    $width = 500;
    $height = 300;
    $image = imagecreate($width, $height);
    $background_color = imagecolorallocate($image, 225, 229, 231);
    $text_color = imagecolorallocate($image, 63, 63, 63);
    $text = $this->get('settings')['title'] .' | '. strtoupper($args['title']);
    imagestring($image, 10, $width / 2 - strlen($text) * 5, $height / 2, $text, $text_color);
    imagepng($image);
    $img = ob_get_clean();
    imagedestroy($image);
    $res->getBody()->write($img);
    return $res->withHeader(
      'Content-Type', 'image/png'
    );
  })->setName('image-creator');

  // index
  $app->get('/', function (Request $req, Response $res) {
    return $this->get('view')->render($res, 'pages/index.html');
  })->setName('index');

  // test key
  $app->get('/test-key', function (Request $req, Response $res) {
      return $this->get('view')
                  ->render($res, 'pages/test-key.html');
  })->setName('test-key')
    ->add('have-key'); // untuk menambahka kunci pada route ini

  // 404 not found page stell
  $app->any('{route:.*}', function ($req, $res) {
      return $this->get('view')
                  ->render($res, 'pages/404.html');
  });

};
