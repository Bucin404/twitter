<?php
declare(strict_types = 1);

use Slim\Middleware\ContentLengthMiddleware;
use Slim\Views\TwigMiddleware;
use Slim\App;

return function (App $app) {
  $app->add(ContentLengthMiddleware::class);
  $app->addBodyParsingMiddleware();
  $app->add(TwigMiddleware::createFromContainer($app));
  $app->addRoutingMiddleware();
  $app->add(
    function ($request, $next) {
      $this->get('flash')->__construct($_SESSION);
      return $next->handle($request);
    }
  );
};
